<?php 
session_start(); 
?>
<html>
<head>
<title>Cheese Emporium - Check Out</title>
<link rel="stylesheet" type="text/css" href="cheese.css" />
</head>
<body>
<h1>Your cart currently contains</h1>
<?php
echo "Cheese: ".$_SESSION["cheesename"]."<br />";
echo "Amount (lbs): ".$_SESSION['cheeseamount']."<br />";
echo "At (per lb): ".$_SESSION["cheeseprice"]."<br />";
echo "Total price: ".$_SESSION["totalprice"]."<br />";
echo "Go <a href='cheese_cart4.php'>here</a> to delete your shopping cart ";
?>
</body>
</html>