<?php 
session_start(); 
?>

<html>
<head>
<title>Cheese Emporium - Shopping Cart</title>
<link rel="stylesheet" type="text/css" href="cheese.css" />
</head>
<body>
<?php 
$cheesename = $_REQUEST['cheesetype'];
$cheeseamount = $_REQUEST['amount'];
$conn=mysqli_connect('localhost','alec.wells','46MSQB66','alecwells_cheesedb');
$sql="SELECT * FROM cheese where cheesename='$cheesename' "; 
if (mysqli_connect_errno())
   {
   echo "Failed to connect to MySQL: " . mysqli_connect_error();
   }
$rs=mysqli_query($conn,$sql);
if (!$rs)
{
	die("Could not get data ".mysql_error());
}
if ($row=mysqli_fetch_array($rs)) {				//if there is an output
$cheeseprice=$row['price'];
}

echo "You have selected ". $cheeseamount." lbs of ".$cheesename." which is priced at ".$cheeseprice." per pound <br />";
$price=$cheeseamount*$cheeseprice;
echo "The price for this cheese transaction is: £".$price."<br />";
$_SESSION["cheeseamount"] = $cheeseamount;
$_SESSION["cheesename"] = $cheesename;
$_SESSION["cheeseprice"] = $cheeseprice;
$_SESSION["totalprice"] = $_SESSION["totalprice"]+$price;
echo "Go <a href='cheese_cart3.php'>here</a> to view your shopping cart ";

mysqli_close($conn);
?>

</body>
</html>