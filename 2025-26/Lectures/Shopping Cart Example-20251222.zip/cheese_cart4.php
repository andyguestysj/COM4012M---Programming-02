<?php 
session_destroy();
?>
<html>
<head>
<title>Cheese Emporium - Empty Cart</title>
<link rel="stylesheet" type="text/css" href="cheese.css" />
</head>
<body>
<h1>Your cart currently contains</h1>
<?php
echo "Cheese: ".$_SESSION["cheesename"]."<br />";
echo "Amount (lbs): ".$_SESSION['cheeseamount']."<br />";
echo "At (per lb): ".$_SESSION["cheeseprice"]."<br />";
echo "Total price: ".$_SESSION["totalprice"]."<br />";
echo "Go <a href='cheese_cart1.html'>here</a> to start your new cheese experience ";
?>
</body>
</html>